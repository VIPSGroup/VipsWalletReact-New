import React from "react";
const Homepage = ({ HomeTopNav }) => {
  return (
    <>
      <HomeTopNav />
    </>
  );
};

export default Homepage;
