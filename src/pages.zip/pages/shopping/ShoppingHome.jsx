import React from "react";

const ShoppingHome = ({ CommonTopNav }) => {
  return (
    <>
      <CommonTopNav />
    </>
  );
};

export default ShoppingHome;
